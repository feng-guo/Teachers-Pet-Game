import game.Game;

public class Main {
	public static void main(String[] args){
		Game game = new Game("Richmond Hill High Simulator", 600, 400);
		game.start();
	}
}