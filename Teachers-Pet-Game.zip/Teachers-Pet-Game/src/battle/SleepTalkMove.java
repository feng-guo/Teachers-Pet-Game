package battle;

class SleepTalkMove extends Move {
    SleepTalkMove (String name, String type, int maxPowerPoints, int priority) {
        super(name, 0, 1.0, type, "none", maxPowerPoints, priority);
    }
}
