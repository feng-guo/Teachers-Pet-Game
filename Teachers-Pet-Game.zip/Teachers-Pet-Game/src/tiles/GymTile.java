package tiles;

import java.awt.image.BufferedImage;

import graphics.Assets;

public class GymTile extends Tile{

    public GymTile(int id) {
        super(Assets.gymTile, id);
    }

}
