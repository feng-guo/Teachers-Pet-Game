package tiles;


import graphics.Assets;

public class PathTile extends Tile {

	public PathTile(int id) {
		super(Assets.path, id);
	}

}
