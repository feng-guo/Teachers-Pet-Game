package tiles;

import java.awt.image.BufferedImage;

import graphics.Assets;

public class HallTile extends Tile{

	public HallTile(int id) {
		super(Assets.floor, id);
	}

}
